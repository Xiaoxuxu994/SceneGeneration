__all__ = [
    "projection_three_dims_gaussian_fused",
    "calc_render",
    "gaussian_sort",
    "get_render_schedule_cpp",
    "spherical_harmonics",
    "flash_gaussian_build_mask",
    "gaussian_filter",
]

import os
import meta_gauss_render._C

from .ops.projection_three_dims_gaussian_fused import projection_three_dims_gaussian_fused
from .ops.calc_render import calc_render
from .ops.gaussian_sort import gaussian_sort
from .ops.get_render_schedule import get_render_schedule_cpp
from .ops.spherical_harmonics import spherical_harmonics
from .ops.flash_gaussian_build_mask import flash_gaussian_build_mask
from .ops.gaussian_filter import gaussian_filter


def _set_env():
    meta_gauss_render_root = os.path.dirname(os.path.abspath(__file__))
    meta_gauss_render_opp_path = os.path.join(meta_gauss_render_root, "packages", "vendors", "customize")
    ascend_custom_opp_path = os.environ.get("ASCEND_CUSTOM_OPP_PATH")
    ascend_custom_opp_path = (
        meta_gauss_render_opp_path
        if not ascend_custom_opp_path
        else meta_gauss_render_opp_path + ":" + ascend_custom_opp_path
    )
    os.environ["ASCEND_CUSTOM_OPP_PATH"] = ascend_custom_opp_path
    meta_gauss_render_op_api_so_path = os.path.join(meta_gauss_render_opp_path, "op_api", "lib", "libcust_opapi.so")
    meta_gauss_render._C._init_op_api_so_path(meta_gauss_render_op_api_so_path)


_set_env()